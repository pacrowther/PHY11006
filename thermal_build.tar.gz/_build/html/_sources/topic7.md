# Topic 7: The Second Law of Thermodynamics and Entropy

# Introduction

In section 6.4 we said that no heat engine can possibly be more efficient than a Carnot engine, and in
section 1.1 we said that when we place two bodies of different temperature in thermal contact, heat
flows from the hotter body to the cooler body. These are, in fact, two statements of the Second Law
of Thermodynamics:

No process can have as its sole result the transfer of heat from a colder to a
hotter body (Clausius Statement)

In other words, heat does not flow spontaneously from cold to hot.

No engine working between two given temperatures TH and TC can be more
efficient than a Carnot engine (Carnot engine statement)

There is also a third statement of the Second Law:

No process can have as its sole result the complete conversion of heat into
work (Kelvin statement)

The Clausius and Kelvin statements of the Second Law are in fact precisely equivalent, though this is
not obvious at first glance, and the Carnot statement can be proved from the Clausius statement.
Notice that both the Clausius and the Kelvin statements imply an arrow of time: if we were to consider
a time-reversed version of Clausius’ statement, we would see heat flowing from the hotter body to
the cooler, which is perfectly legitimate, and likewise a time-reversed version of the Kelvin statement
would involve the complete conversion of work into heat, which is also legitimate.


